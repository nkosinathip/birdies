import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.Timer;

public class Example {

    private static final JPanel square = new JPanel();
    private static int x = 20;

    public static void createAndShowGUI(){
        /// J FRAME 

        JFrame frame = new JFrame();
        frame.getContentPane().setLayout(null);
        frame.setSize(500,700);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ///// DESIGN OF THE THE OBJECT 

        frame.add(square);
        square.setBounds(20,200,100,100);
        square.setBackground(Color.BLUE);
        // MOTION 

        Timer timer = new Timer(1,new MyActionListener());
        timer.start();
        frame.setVisible(true);
    }

    public static class MyActionListener implements ActionListener{
        // WHERE THE OBJECT IS LOCATED 

        @Override
        public void actionPerformed(ActionEvent arg0) {
            square.setLocation(x++, 100);

        }

    }

    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(new Runnable(){
            @Override
            public void run(){
                createAndShowGUI();

            }
        });


    }

}